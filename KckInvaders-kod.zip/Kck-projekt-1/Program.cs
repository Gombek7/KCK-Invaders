﻿using Kck_projekt_1.Views;
using System;

namespace Kck_projekt_1
{
    class Program
    {
        static void Main(string[] args)
        {
            (new ConsoleView()).Start();
        }
    }
}
